// No clipboard conversion here: PagePick's existing capture/paste pipeline stays intact.
figma.showUI(__html__, {width:360,height:460,themeColors:true});
const STATE_KEY='pagepick.arrangement.v1';
let pending=null,committing=false;
let automatic=false;
const completed=new Map();
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function state(page) {
  const raw=page.getPluginData(STATE_KEY);
  if(!raw)return null;
  const parsed=JSON.parse(raw);
  if(!Number.isFinite(parsed.right) || !Number.isFinite(parsed.y))throw Error('排列记录损坏，请先重置排列记录');
  return parsed;
}
function progress(text){figma.ui.postMessage({type:'STATUS',text});}
async function handle(m) {
  if(m.command==='AUTO_START') {
    if(automatic || pending)throw Error('已在接收或存在待命任务');
    if(!Number.isInteger(m.gap) || m.gap<0 || m.gap>10000)throw Error('间隔必须是 0–10000 的整数');
    automatic=true;
    await handle({command:'BEGIN',jobId:'auto-'+Date.now(),gap:m.gap});
    figma.ui.hide();
    // Local development plugins run in the desktop editor. No network bridge is needed in this mode.
    (async()=>{
      while(automatic) {
        try {
          const jobId=pending.jobId;
          await handle({command:'COMMIT',jobId});
          await handle({command:'BEGIN',jobId:'auto-'+Date.now(),gap:m.gap});
        } catch(error) {
          if(error.message.includes('未确认新增画板'))continue;
          automatic=false;figma.ui.show();progress(error.message);
        }
      }
    })();
    return {ok:true,automatic:true};
  }
  if(m.command==='PING')return {ok:true,version:'1.0.0',pageId:figma.currentPage.id,pageName:figma.currentPage.name,anchor:state(figma.currentPage)};
  if(m.command==='RESET') {
    if(pending || committing)throw Error('仍有待处理任务，请先取消待命');
    figma.currentPage.setPluginData(STATE_KEY,'');
    progress('已重置；下一张从 (0, 0) 开始');return {ok:true};
  }
  if(m.command==='CANCEL') {
    if(committing)throw Error('正在确认排列结果，请稍候');
    if(pending && pending.jobId!==m.jobId)throw Error('任务编号不匹配');
    pending=null;progress('待命已取消，成功位置记录保留');return {ok:true};
  }
  if(m.command==='BEGIN') {
    if(completed.has(m.jobId))return completed.get(m.jobId);
    if(pending){if(pending.jobId===m.jobId)return {ok:true,armed:true};throw Error('排列器正在等待上一项任务，请先完成或取消');}
    if(typeof m.jobId!=='string' || m.jobId.length>100)throw Error('任务编号无效');
    if(!Number.isInteger(m.gap) || m.gap<0 || m.gap>10000)throw Error('间隔必须是 0–10000 的整数');
    const page=figma.currentPage;
    pending={jobId:m.jobId,page,before:new Set(page.children.map(n=>n.id)),gap:m.gap,anchor:state(page)};
    progress('已待命：等待本次新增画板');return {ok:true,armed:true,pageId:page.id};
  }
  if(m.command!=='COMMIT')throw Error('不支持的排列器命令');
  if(completed.has(m.jobId))return completed.get(m.jobId);
  if(committing)throw Error('正在确认排列，请勿重复提交');
  if(!pending || pending.jobId!==m.jobId)throw Error('没有对应的待命任务，请先重新连接并捕获');
  const task=pending;committing=true;
  try {
    let chosen=null,signature='',stable=0;
    const deadline=Date.now()+45000;
    while(Date.now()<deadline) {
      if(figma.currentPage.id!==task.page.id)throw Error('捕获期间切换了 Figma 页面，未移动任何内容');
      const added=task.page.children.filter(n=>!task.before.has(n.id));
      if(added.length>1)throw Error('发现多个新增顶层对象，无法唯一识别本次画板；未移动任何内容');
      if(added.length===1) {
        const n=added[0];
        if(n.type!=='FRAME')throw Error('新增对象不是画板；未移动任何内容');
        const next=JSON.stringify([n.id,n.width,n.height,n.findAll().length]);
        stable=next===signature?stable+1:0;signature=next;
        if(stable>=4 && n.width>0 && n.height>0){chosen=n;break;}
      }
      await sleep(300);
    }
    if(!chosen)throw Error('未确认新增画板；上次成功的位置已保留，可重试确认');
    const node=chosen,old={x:node.x,y:node.y};
    const x=task.anchor?task.anchor.right+task.gap:0,y=task.anchor?task.anchor.y:0;
    try {
      node.x=x;node.y=y;
      if(Math.abs(node.x-x)>0.01 || Math.abs(node.y-y)>0.01)throw Error('Figma 坐标回读不一致');
      const anchor={nodeId:node.id,x:node.x,y:node.y,width:node.width,right:node.x+node.width,jobId:task.jobId};
      task.page.setPluginData(STATE_KEY,JSON.stringify(anchor));
      const result={ok:true,confirmed:true,arranged:true,...anchor,pageId:task.page.id};
      completed.set(task.jobId,result);if(completed.size>30)completed.delete(completed.keys().next().value);
      pending=null;progress(`排列成功 · X ${node.x} / Y ${node.y} · 间隔 ${task.gap}`);
      return result;
    } catch(error) {node.x=old.x;node.y=old.y;throw error;}
  } finally {committing=false;}
}
figma.ui.onmessage=async m=>{
  if(!m || m.type!=='PAGEPICK_REQUEST')return;
  try {figma.ui.postMessage({type:'PAGEPICK_RESPONSE',requestId:m.requestId,result:await handle(m)});}
  catch(error){progress(error.message);figma.ui.postMessage({type:'PAGEPICK_RESPONSE',requestId:m.requestId,result:{ok:false,error:error.message}});}
};
progress('开启接收后，回到浏览器点击拾页图标。');
